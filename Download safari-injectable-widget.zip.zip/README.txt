📱 Safari Widget Loader

1. HOST:
   - Upload to GitHub Pages, Netlify, or Vercel.
   - Folder structure must remain as-is.

2. BOOKMARKLET:
   - Open bookmarklet.js and copy the full URL string.
   - Add a Safari bookmark and paste it in the URL field.

3. ADD TO HOME SCREEN:
   - Open index.html on iOS Safari.
   - Tap Share → Add to Home Screen.

Now tap your icon and launch the widget like an app!
