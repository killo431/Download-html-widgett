// Paste this URL into Safari bookmark address field:
javascript:(async()=>{const r=await fetch('https://yourdomain.com/widgets/my-widget/template.html');const h=await r.text();const d=document.createElement('div');d.innerHTML=h;document.body.appendChild(d);})();
